package com.dor.carlink

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var macBox: EditText
    private lateinit var toggle: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 3, pad, pad)
        }
        fun label(t: String, size: Float = 16f) = TextView(this).apply { text = t; textSize = size; setPadding(0, pad / 2, 0, pad / 4) }

        root.addView(label("CarLink", 28f))
        root.addView(label("Car box MAC address"))
        macBox = EditText(this).apply {
            setText(Prefs.mac(this@MainActivity))
            inputType = InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            isSingleLine = true
        }
        root.addView(macBox)

        toggle = Button(this).apply { setOnClickListener { onToggle() } }
        root.addView(toggle)

        root.addView(Button(this).apply {
            text = "Connect now"
            setOnClickListener { connectNow() }
        })
        root.addView(Button(this).apply {
            text = "Battery: allow background"
            setOnClickListener { askBattery() }
        })

        status = label("", 15f).apply { gravity = Gravity.START }
        root.addView(status)
        root.addView(label(
            "Tip: add the \"Connect car\" tile to Quick Settings for a one-tap connect.", 13f
        ))
        setContentView(root)
        requestPerms()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        toggle.text = if (Prefs.watching(this)) "Stop watching" else "Start watching for car"
        status.text = "Status: " + Prefs.lastStatus(this)
    }

    private fun saveMac(): Boolean {
        val mac = macBox.text.toString().trim().uppercase()
        if (!Regex("([0-9A-F]{2}:){5}[0-9A-F]{2}").matches(mac)) {
            status.text = "That doesn't look like a MAC address"
            return false
        }
        Prefs.setMac(this, mac)
        return true
    }

    private fun hasBt() = checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun onToggle() {
        if (!saveMac()) return
        if (!hasBt()) { requestPerms(); return }
        if (Prefs.watching(this)) WatchService.stop(this) else WatchService.start(this)
        refresh()
    }

    private fun connectNow() {
        if (!saveMac()) return
        if (!hasBt()) { requestPerms(); return }
        status.text = "Status: connecting…"
        Thread {
            val r = Connector.connect(this, Prefs.mac(this))
            Prefs.setLastStatus(this, r)
            runOnUiThread { refresh() }
        }.start()
    }

    @SuppressLint("BatteryLife")
    private fun askBattery() {
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } else {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }

    private fun requestPerms() {
        val need = listOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.POST_NOTIFICATIONS)
            .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }
}
