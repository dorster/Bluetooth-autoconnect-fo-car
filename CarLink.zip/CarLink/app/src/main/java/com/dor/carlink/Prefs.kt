package com.dor.carlink

import android.content.Context

object Prefs {
    const val DEFAULT_MAC = "CC:C4:B2:DD:7D:40" // smartBox-7D40
    private fun sp(ctx: Context) = ctx.getSharedPreferences("carlink", Context.MODE_PRIVATE)

    fun mac(ctx: Context): String = sp(ctx).getString("mac", DEFAULT_MAC) ?: DEFAULT_MAC
    fun setMac(ctx: Context, v: String) = sp(ctx).edit().putString("mac", v.trim().uppercase()).apply()

    fun watching(ctx: Context): Boolean = sp(ctx).getBoolean("watching", false)
    fun setWatching(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("watching", v).apply()

    fun lastStatus(ctx: Context): String = sp(ctx).getString("status", "Idle") ?: "Idle"
    fun setLastStatus(ctx: Context, v: String) = sp(ctx).edit().putString("status", v).apply()
}
