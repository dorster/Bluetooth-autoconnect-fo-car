package com.dor.carlink

import android.annotation.SuppressLint
import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHeadset
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.util.Log
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Pokes the paired car box so it brings up the Bluetooth link.
 * Once the box is connected it hands the phone its Wi-Fi and Android Auto starts by itself.
 */
@SuppressLint("MissingPermission")
object Connector {
    private const val TAG = "CarLink"
    private val SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    // Hands-free / headset service UUIDs: tried last so we don't sit on the box's call channel.
    private val CALL_UUIDS = setOf(
        UUID.fromString("0000111E-0000-1000-8000-00805F9B34FB"),
        UUID.fromString("00001108-0000-1000-8000-00805F9B34FB"),
    )

    /** True if the box is already connected for calls or audio. */
    fun isConnected(ctx: Context, mac: String): Boolean {
        val adapter = ctx.getSystemService(BluetoothManager::class.java)?.adapter ?: return false
        if (!adapter.isEnabled) return false
        for (profile in listOf(BluetoothProfile.HEADSET, BluetoothProfile.A2DP)) {
            val latch = CountDownLatch(1)
            var found = false
            val ok = adapter.getProfileProxy(ctx, object : BluetoothProfile.ServiceListener {
                override fun onServiceConnected(p: Int, proxy: BluetoothProfile) {
                    try {
                        found = proxy.connectedDevices.any { it.address.equals(mac, true) }
                    } catch (_: Exception) {}
                    adapter.closeProfileProxy(p, proxy)
                    latch.countDown()
                }
                override fun onServiceDisconnected(p: Int) { latch.countDown() }
            }, profile)
            if (ok) latch.await(2, TimeUnit.SECONDS)
            if (found) return true
        }
        return false
    }

    /** One connection attempt. Returns a short status line. Call off the main thread. */
    fun connect(ctx: Context, mac: String): String {
        val adapter = ctx.getSystemService(BluetoothManager::class.java)?.adapter
            ?: return "No Bluetooth adapter"
        if (!adapter.isEnabled) return "Bluetooth is off"
        val dev: BluetoothDevice = try { adapter.getRemoteDevice(mac.uppercase()) }
            catch (e: IllegalArgumentException) { return "Bad MAC address" }
        if (dev.bondState != BluetoothDevice.BOND_BONDED) return "Box isn't paired with this phone"
        if (isConnected(ctx, mac)) return "Already connected"

        // 1) Ask the phone's own call/audio profiles to connect (only works if the ROM allows it).
        tryProfileConnect(ctx, dev)

        // 2) Open a raw link to the box. Even a refused socket pages the box and brings up
        //    the Bluetooth link, which makes the box connect its profiles on its own.
        val uuids = (dev.uuids?.map { it.uuid } ?: emptyList()).distinct()
        val order = (uuids.filterNot { it in CALL_UUIDS } + SPP + uuids.filter { it in CALL_UUIDS }).distinct()
        var last = "no services"
        for (u in order) {
            try {
                val s = dev.createInsecureRfcommSocketToServiceRecord(u)
                s.connect()
                Thread.sleep(1500)
                s.close()
                Log.i(TAG, "Socket ok on $u")
                return "Link opened"
            } catch (e: Exception) {
                last = e.message ?: e.javaClass.simpleName
                Log.d(TAG, "Socket $u failed: $last")
            }
            if (isConnected(ctx, mac)) return "Connected"
        }
        Thread.sleep(2000)
        return if (isConnected(ctx, mac)) "Connected" else "Box not reachable ($last)"
    }

    private fun tryProfileConnect(ctx: Context, dev: BluetoothDevice) {
        val adapter = ctx.getSystemService(BluetoothManager::class.java)?.adapter ?: return
        for (profile in listOf(BluetoothProfile.HEADSET, BluetoothProfile.A2DP)) {
            val latch = CountDownLatch(1)
            val ok = adapter.getProfileProxy(ctx, object : BluetoothProfile.ServiceListener {
                override fun onServiceConnected(p: Int, proxy: BluetoothProfile) {
                    try {
                        val cls = if (proxy is BluetoothHeadset) BluetoothHeadset::class.java else BluetoothA2dp::class.java
                        cls.getMethod("connect", BluetoothDevice::class.java).invoke(proxy, dev)
                        Log.i(TAG, "Profile $p connect called")
                    } catch (e: Throwable) {
                        Log.d(TAG, "Profile $p connect blocked: ${e.javaClass.simpleName}")
                    }
                    adapter.closeProfileProxy(p, proxy)
                    latch.countDown()
                }
                override fun onServiceDisconnected(p: Int) { latch.countDown() }
            }, profile)
            if (ok) latch.await(2, TimeUnit.SECONDS)
        }
    }
}
