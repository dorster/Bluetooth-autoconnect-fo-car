package com.dor.carlink

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && Prefs.watching(ctx)) {
            try { WatchService.start(ctx) } catch (_: Exception) {}
        }
    }
}
