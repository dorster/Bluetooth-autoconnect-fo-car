package com.dor.carlink

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast

/** Quick Settings tile: one tap tries to connect the car box right now. */
class ConnectTile : TileService() {
    override fun onStartListening() {
        qsTile?.apply { state = Tile.STATE_INACTIVE; label = "Connect car"; updateTile() }
    }

    override fun onClick() {
        qsTile?.apply { state = Tile.STATE_ACTIVE; subtitle = "Connecting…"; updateTile() }
        Thread {
            val result = Connector.connect(this, Prefs.mac(this))
            mainExecutor.execute {
                qsTile?.apply { state = Tile.STATE_INACTIVE; subtitle = result; updateTile() }
                Toast.makeText(this, "CarLink: $result", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }
}
