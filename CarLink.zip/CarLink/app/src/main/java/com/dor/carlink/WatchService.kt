package com.dor.carlink

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Keeps trying to reach the car box every few seconds while it isn't connected.
 * Pauses while connected and resumes when the link drops.
 */
@SuppressLint("MissingPermission")
class WatchService : Service() {

    companion object {
        const val ACTION_STOP = "com.dor.carlink.STOP"
        private const val CHANNEL = "watch"
        private const val NOTIF_ID = 1
        private const val INTERVAL_MS = 20_000L

        fun start(ctx: Context) {
            Prefs.setWatching(ctx, true)
            ctx.startForegroundService(Intent(ctx, WatchService::class.java))
        }
        fun stop(ctx: Context) {
            Prefs.setWatching(ctx, false)
            ctx.startService(Intent(ctx, WatchService::class.java).setAction(ACTION_STOP))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    @Volatile private var connected = false
    private val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private val tick = object : Runnable {
        override fun run() {
            if (!connected) attempt()
            handler.postDelayed(this, INTERVAL_MS)
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                BluetoothDevice.ACTION_ACL_CONNECTED, BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                    val dev = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    if (dev?.address.equals(Prefs.mac(c), true)) {
                        connected = i.action == BluetoothDevice.ACTION_ACL_CONNECTED
                        update(if (connected) "Connected to car" else "Car disconnected, watching")
                        if (!connected) { handler.removeCallbacks(tick); handler.postDelayed(tick, 3000) }
                    }
                }
                BluetoothAdapter.ACTION_STATE_CHANGED -> {
                    if (i.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1) == BluetoothAdapter.STATE_ON) {
                        handler.removeCallbacks(tick); handler.postDelayed(tick, 2000)
                    }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Car watch", NotificationManager.IMPORTANCE_LOW)
        )
        startForeground(NOTIF_ID, build("Watching for car"), ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        registerReceiver(receiver, IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        })
        worker.execute {
            connected = Connector.isConnected(this, Prefs.mac(this))
            handler.post {
                update(if (connected) "Connected to car" else "Watching for car")
                handler.post(tick)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun attempt() {
        if (!busy.compareAndSet(false, true)) return
        worker.execute {
            val result = try { Connector.connect(this, Prefs.mac(this)) } finally { busy.set(false) }
            if (result == "Connected" || result == "Already connected") connected = true
            handler.post { update("${time.format(Date())}  $result") }
        }
    }

    private fun update(text: String) {
        Prefs.setLastStatus(this, text)
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, build(text))
    }

    private fun build(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WatchService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_car)
            .setContentTitle("CarLink")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build())
            .build()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        worker.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
