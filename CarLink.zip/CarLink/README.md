# CarLink

Auto-connects my phone to the car's smartBox wireless Android Auto box over Bluetooth.
Once Bluetooth connects, the box hands over its Wi-Fi and Android Auto starts by itself.

- **Start watching**: tries to reach the box every 20 s while it's not connected (pauses while connected).
- **Connect now** / **Quick Settings tile**: one manual attempt.
- Set battery to *Unrestricted* or OxygenOS will kill the watcher.

The APK is built by GitHub Actions: Actions tab → latest run → `CarLink-apk`.
